<?php
$host = '170.64.192.236';
$user = "teamnameisgroup1";
$pwd = "COS60010istheclasscode";
$sql_db = "chemquiz";
?>