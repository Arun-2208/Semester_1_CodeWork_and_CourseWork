<?php
$host = 'localhost';
$user = "root";
$pwd = "";
$sql_db = "Chemquiz";
?>