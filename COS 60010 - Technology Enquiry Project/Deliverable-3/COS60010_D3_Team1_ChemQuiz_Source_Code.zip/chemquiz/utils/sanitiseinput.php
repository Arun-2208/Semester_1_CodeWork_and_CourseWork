<?php
// COS60004 Lab 08 - Server-side Data Validation
function sanitise_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>


